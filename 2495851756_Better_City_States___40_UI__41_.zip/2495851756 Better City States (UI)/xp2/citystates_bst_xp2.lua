-- ===========================================================================
-- Better City States
-- Author: Infixo
-- This file is needed for compatibility with CQUI
-- ===========================================================================
include("CityStates_Expansion2");
